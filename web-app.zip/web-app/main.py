import sagemaker
import boto3
from keras.preprocessing import image
import numpy as np
def getPrediction(filename):

	my_region = boto3.session.Session().region_name
	session=boto3.Session()
	sagemaker_session = sagemaker.Session(boto_session=session)
	role = 'arn:aws:iam::188327064878:role/service-role/AmazonSageMaker-ExecutionRole-20201203T152186'


	endpoint_name="tensorflow-inference-2020-12-29-21-53-16-964"
	from sagemaker.tensorflow.model import TensorFlowModel
	predictor=sagemaker.tensorflow.model.TensorFlowPredictor(endpoint_name, sagemaker_session)
	testc= image.load_img('uploads/'+filename,target_size=(220,220))
	test_img=image.img_to_array(testc)
	test_final_image=np.expand_dims(test_img,axis=0)
	result=predictor.predict(test_final_image)
	res=result['predictions']
	ind=np.argmax(res)
	label=res[0][ind]
	name_dic={'adonis': 0,
	 'american snoot': 1,
	 'an 88': 2,
	 'banded peacock': 3,
	 'beckers white': 4,
	 'black hairstreak': 5,
	 'cabbage white': 6,
	 'chestnut': 7,
	 'clodius parnassian': 8,
	 'clouded sulphur': 9,
	 'copper tail': 10,
	 'crecent': 11,
	 'crimson patch': 12,
	 'eastern coma': 13,
	 'gold banded': 14,
	 'great eggfly': 15,
	 'grey hairstreak': 16,
	 'indra swallow': 17,
	 'julia': 18,
	 'large marble': 19,
	 'malachite': 20,
	 'mangrove skipper': 21,
	 'metalmark': 22,
	 'monarch': 23,
	 'morning cloak': 24,
	 'orange oakleaf': 25,
	 'orange tip': 26,
	 'orchard swallow': 27,
	 'painted lady': 28,
	 'paper kite': 29,
	 'peacock': 30,
	 'pine white': 31,
	 'pipevine swallow': 32,
	 'purple hairstreak': 33,
	 'question mark': 34,
	 'red admiral': 35,
	 'red spotted purple': 36,
	 'scarce swallow': 37,
	 'silver spot skipper': 38,
	 'sixspot burnet': 39,
	 'skipper': 40,
	 'sootywing': 41,
	 'southern dogface': 42,
	 'straited queen': 43,
	 'two barred flasher': 44,
	 'ulyses': 45,
	 'viceroy': 46,
	 'wood satyr': 47,
	 'yellow swallow tail': 48,
	 'zebra long wing': 49}
	name=list(name_dic)
	return name[ind], str(res[0][ind])
